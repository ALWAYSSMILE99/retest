package com.order.exception;

public class orderException extends Exception {
	public orderException()
	{
		super();
	}
	public orderException(String msg)
	{
		super(msg);
	}
	

}

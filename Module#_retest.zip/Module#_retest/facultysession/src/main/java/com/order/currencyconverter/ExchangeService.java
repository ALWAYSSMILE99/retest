package com.order.currencyconverter;

public interface ExchangeService {
	public double getExchangeRate();
}

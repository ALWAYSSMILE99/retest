package com.order.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.bean.order1;
import com.order.dao.orderDao;
import com.order.exception.orderException;
@Service
public class orderServiceImpl implements orderService {
	@Autowired
     orderDao orderDao;
	

	@Override
	public List<order1> addSession(order1 b) throws orderException {

		try {
			orderDao.save(b);
	        return orderDao.findAll();
	        }catch(Exception e) {
	            throw new orderException(e.getMessage());
	        }
		
	}

	@Override
	public List<order1> updateSession(int id, order1 b) throws orderException {
		try
		{
			Optional<order1> optional=orderDao.findById(id);
			if(optional.isPresent())
			{
				order1 s=optional.get();
				s.setId(b.getId());
				s.setPrice(b.getPrice());
				s.setQuantity(b.getQuantity());
				s.setAmount(b.getAmount());
				s.setCharges(b.getCharges());
				
				orderDao.save(s);
				return getAllSessions();
			}
			else
			{
				throw new orderException("session with Id"+id+" does not exist");	
			}
		}
			catch(Exception e)
		   {
	            throw new orderException(e.getMessage());	
	       }
	}

	@Override
	public List<order1> getAllSessions() throws orderException {
		try
		{
			return orderDao.findAll();
		}
		catch(Exception e)
		{
			throw new orderException(e.getMessage());
		}
		
	}

	@Override
	public void deleteSession(int id) throws orderException {
		// TODO Auto-generated method stub
		try
		{
			orderDao.deleteById(id);
		}
		catch(Exception e)
		{
			throw new orderException(e.getMessage());
		}
		
	}
	

}




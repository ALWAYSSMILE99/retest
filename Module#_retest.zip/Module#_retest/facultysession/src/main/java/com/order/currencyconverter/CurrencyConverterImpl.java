package com.order.currencyconverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("currencyConverter")
public class CurrencyConverterImpl implements CurrencyConverter {
	
	
	// currencyConverterImpl 
	

	public CurrencyConverterImpl() {
		System.out.println("CurrencyConverterImpl()");
	}
	@Autowired
	public CurrencyConverterImpl(ExchangeServiceImpl exchangeService) {
		System.out.println("CurrencyConverterImpl()");
		this.exchangeService = exchangeService;
	}
	
	@Autowired
	private ExchangeServiceImpl exchangeService;

	
	public double dollarsToRupees(double price) {
		System.out.println("dollarsToRupees()");		
		return price * exchangeService.getExchangeRate();
	}
};
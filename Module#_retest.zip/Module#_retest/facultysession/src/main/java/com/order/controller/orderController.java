package com.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.order.bean.order1;
import com.order.exception.orderException;
import com.order.service.orderService;

@RestController
public class orderController {
	@Autowired
	orderService orderService;
	
	@RequestMapping("/orderlist")
	public List <order1> getAllSessions() throws orderException
	{
		return orderService.getAllSessions();
	}
	
	@RequestMapping(value="/addorder", method=RequestMethod.POST)
	public List<order1> addSession(@RequestBody order1 b) throws orderException{
		return orderService.addSession(b);
			}
	
	
	@DeleteMapping("/deleteorder/{id}")	
	public ResponseEntity<String> deleteSession(@PathVariable int id) throws orderException {
	orderService.deleteSession(id);
	return new ResponseEntity<String> ("session with id "+id+" deleted",HttpStatus.OK);
	}
	
	
	
	@PutMapping("/updateorder/{id}")
	public List <order1> updateSession(@PathVariable int id, @RequestBody order1 b) throws orderException{
		return orderService.updateSession(id, b);
	}
	
}

package com.order.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.order.bean.order1;
@Repository
public interface orderDao extends JpaRepository<order1, Integer> {
	@Query("from order1 where idr=:c")
	List<order1> getSessionById(@Param("c")int id);
	
}

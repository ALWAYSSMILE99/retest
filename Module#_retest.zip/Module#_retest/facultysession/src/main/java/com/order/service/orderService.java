package com.order.service;

import java.util.List;

import com.order.bean.order1;
import com.order.exception.orderException;

public interface orderService {

	public List<order1> addSession(order1 b) throws orderException;
	public List<order1> updateSession(int id, order1 b) throws orderException;
	public List<order1> getAllSessions() throws orderException;
	
	public void deleteSession (int id) throws orderException;	
}

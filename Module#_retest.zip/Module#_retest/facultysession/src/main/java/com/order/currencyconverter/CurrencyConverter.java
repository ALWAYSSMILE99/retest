package com.order.currencyconverter;
public interface CurrencyConverter {
	public double dollarsToRupees(double price);
}
package com.stock.exception;

public class StockException extends Exception {
	public StockException()
	{
		super();
	}
	public StockException(String msg)
	{
		super(msg);
	}
	

}

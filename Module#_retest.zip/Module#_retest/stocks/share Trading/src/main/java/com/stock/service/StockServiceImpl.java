package com.stock.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.bean.Stock;
import com.stock.dao.StockRepository;
import com.stock.exception.StockException;

@Service
public class StockServiceImpl implements StockService {
	@Autowired
	StockRepository StoRep;	
	
	@Override
	public List<Stock> createStock(Stock pro) throws StockException {
		
		
		try {
			 pro=createdata(pro);
			 StoRep.save(pro);
		        return StoRep.findAll();
		        }catch(Exception e) {
		            throw new StockException(e.getMessage());
		        }
	}
	
	
	public  Stock createdata(Stock pro)
	{
		int q=pro.getQuantity();
		int p=pro.getPrice();
		double a=p*q;
		double b;
		if(q>100)
		{
			b=(a*(0.3))/100;
		}
		else
		{
			b=(a*(0.5)/100);
		}
		pro.setAmount(a);
		pro.setBrokerage(b);
		return pro;
	}
	
	

	
	@Override
	public Stock findSingleStock(Integer id) throws StockException {
		try
		{
			return StoRep.findById(id).get();
		}
		catch (Exception ex)
		{
			throw new StockException(ex.getMessage());
		}
		
	}

	@Override
	public List<Stock> viewAllStock() throws StockException {
		try
		{
			return StoRep.findAll();
		}
		catch(Exception e)
		{
			throw new StockException(e.getMessage());
		}
	}

	@Override
	public List<Stock> updateStock(Integer id, Stock pro) throws StockException {
		try
		{
			Optional<Stock> optional=StoRep.findById(id);
			if(optional.isPresent())
			{
				Stock product=optional.get();
				product.setName(pro.getName());
				//product.setModel(pro.getModel());
				product.setPrice(pro.getPrice());
				product.setQuantity(pro.getQuantity());
				product.setAmount(pro.getAmount());
				product.setBrokerage(pro.getBrokerage());
				StoRep.save(product);
				return viewAllStock();
			}
			else
			{
				throw new StockException("Product with the Id"+id+" is not present please enter a valid one ");	
			}
		}
			catch(Exception e) {
	            throw new StockException(e.getMessage());
			
	}
	}


	@Override
	public void deleteStock(Integer id) throws StockException {
		try
		{
			StoRep.deleteById(id);
		}
		catch(Exception e)
		{
			throw new StockException(e.getMessage());
		}
		
	}
	
	
}



